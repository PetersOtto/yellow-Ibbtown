<?php
// Enumeratetheme extension, experimental

class YellowEnumeratetheme {
    const VERSION = "0.9.1";
    public $yellow;         // access to API
    
    // Handle initialisation
    public function onLoad($yellow) {
        $this->yellow = $yellow;
    }
    
    // Handle enumeration
    public function onEnumerate($action, $context) {
        $output = null;
        if ($action=="theme") {
            $path = $this->yellow->system->get("coreThemeDirectory");
            $output = $this->yellow->toolbox->getDirectoryEntries($path, "/.*/", false, true, false);
        }
        return $output;
    }
}